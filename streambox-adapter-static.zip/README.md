# DrElwiss StreamBox Adapter

Bu klasörü GitHub reposunda `streambox-adapter/` olarak yükleyin.

StreamBox'a eklenecek Raw manifest bağlantısı:
https://raw.githubusercontent.com/DrElwiss/DrElwiss/main/streambox-adapter/manifest.json
