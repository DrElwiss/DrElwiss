# FilmMakinesi Stremio katalog adaptörü

Bu paket StreamBox/Stremio için katalog ve metadata sağlar.

## Neden sadece manifest.json yetmiyor?
Stremio manifest dosyası yalnızca hangi kaynakların bulunduğunu tarif eder.
Film/dizi listesi için ayrıca `/catalog/...` ve `/meta/...` endpointleri gerekir.

## Kurulum
1. FilmMakinesi backend'inde şu JSON'u döndüren bir endpoint oluştur:
   `https://filmmakinesi.to/api/stremio/catalog`
2. JSON şekli için `catalog-source.example.json` dosyasını kullan.
3. Bu paketi Node.js sunucunda çalıştır:
   - `npm install`
   - `npm start`
4. Reverse proxy ile örneğin şu adrese yayınla:
   `https://filmmakinesi.to/stremio/manifest.json`
5. StreamBox'a bu manifest adresini ekle.

## Endpointler
- `/manifest.json`
- `/catalog/movie/filmmakinesi_filmler.json`
- `/catalog/series/filmmakinesi_diziler.json`
- `/meta/movie/fm:<id>.json`
- `/meta/series/fm:<id>.json`

## Not
Bu paket yalnızca katalog/metadata içindir. Yayın akışı çıkarmıyor.
Kendi kullanım hakkına sahip videolar için ayrı bir `stream` endpointi eklenebilir.
