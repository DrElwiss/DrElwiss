/**
 * FilmMakinesi -> Stremio katalog/metadata adaptörü
 *
 * Amaç:
 * - /manifest.json
 * - /catalog/movie/filmmakinesi_filmler.json
 * - /catalog/series/filmmakinesi_diziler.json
 * - /meta/movie/:id.json
 * - /meta/series/:id.json
 *
 * Bu örnek yayın/stream çıkarmıyor.
 * Veriyi sitenin kendi backend JSON endpoint'inden okur.
 */

const express = require("express");

const app = express();
const PORT = process.env.PORT || 7000;

// Sitenin kendi backend'inde oluşturacağın güvenli JSON endpoint.
// Örnek: https://filmmakinesi.to/api/stremio/catalog
const SOURCE_URL =
  process.env.FM_CATALOG_SOURCE ||
  "https://filmmakinesi.to/api/stremio/catalog";

const manifest = {
  id: "to.filmmakinesi.catalog",
  version: "1.0.0",
  name: "FilmMakinesi Katalog",
  description: "FilmMakinesi film ve dizi katalog/metadata eklentisi.",
  resources: ["catalog", "meta"],
  types: ["movie", "series"],
  idPrefixes: ["fm:"],
  catalogs: [
    {
      type: "movie",
      id: "filmmakinesi_filmler",
      name: "FilmMakinesi — Filmler",
      extra: [{ name: "search", isRequired: false }]
    },
    {
      type: "series",
      id: "filmmakinesi_diziler",
      name: "FilmMakinesi — Diziler",
      extra: [{ name: "search", isRequired: false }]
    }
  ]
};

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "*");
  next();
});

app.get("/manifest.json", (_req, res) => res.json(manifest));

let cache = { at: 0, data: null };
const CACHE_MS = 5 * 60 * 1000;

async function loadSource() {
  const now = Date.now();
  if (cache.data && now - cache.at < CACHE_MS) return cache.data;

  const r = await fetch(SOURCE_URL, {
    headers: { "Accept": "application/json" }
  });

  if (!r.ok) {
    throw new Error(`Catalog source HTTP ${r.status}`);
  }

  const data = await r.json();

  if (!data || !Array.isArray(data.items)) {
    throw new Error("Kaynak JSON içinde items[] bulunamadı");
  }

  cache = { at: now, data };
  return data;
}

function toMetaPreview(item) {
  return {
    id: `fm:${item.id}`,
    type: item.type === "series" ? "series" : "movie",
    name: item.title,
    poster: item.poster || undefined,
    background: item.background || undefined,
    description: item.description || undefined,
    genres: Array.isArray(item.genres) ? item.genres : undefined,
    releaseInfo: item.year ? String(item.year) : undefined
  };
}

app.get("/catalog/:type/:catalog.json", async (req, res) => {
  try {
    const { type, catalog } = req.params;
    const q = String(req.query.search || "").trim().toLowerCase();

    const expected =
      type === "movie" ? "filmmakinesi_filmler" :
      type === "series" ? "filmmakinesi_diziler" : null;

    if (!expected || catalog !== expected) return res.json({ metas: [] });

    const source = await loadSource();
    let items = source.items.filter(x => x.type === type);

    if (q) {
      items = items.filter(x =>
        String(x.title || "").toLowerCase().includes(q)
      );
    }

    res.json({ metas: items.map(toMetaPreview) });
  } catch (e) {
    res.status(500).json({ error: e.message, metas: [] });
  }
});

app.get("/meta/:type/:id.json", async (req, res) => {
  try {
    const source = await loadSource();
    const rawId = decodeURIComponent(req.params.id);
    const id = rawId.startsWith("fm:") ? rawId.slice(3) : rawId;

    const item = source.items.find(x =>
      String(x.id) === String(id) &&
      (x.type === req.params.type)
    );

    if (!item) return res.status(404).json({ meta: null });

    const meta = {
      ...toMetaPreview(item)
    };

    if (item.type === "series" && Array.isArray(item.episodes)) {
      meta.videos = item.episodes.map(ep => ({
        id: `fm:${item.id}:${ep.season}:${ep.episode}`,
        title: ep.title || `S${ep.season}E${ep.episode}`,
        season: Number(ep.season),
        episode: Number(ep.episode),
        released: ep.released || undefined,
        thumbnail: ep.thumbnail || undefined,
        overview: ep.description || undefined
      }));
    }

    res.json({ meta });
  } catch (e) {
    res.status(500).json({ error: e.message, meta: null });
  }
});

app.listen(PORT, () => {
  console.log(`FilmMakinesi Stremio adapter: http://localhost:${PORT}/manifest.json`);
});
